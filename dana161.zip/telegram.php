<?php
$id_telegram = "7632481591";
$id_botTele  = "8310387541:AAG2mUB7w9PQzglJBQto6A_6ZyEzoqsczMM";
?>